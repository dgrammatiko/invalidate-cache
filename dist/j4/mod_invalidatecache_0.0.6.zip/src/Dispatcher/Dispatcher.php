<?php
/**
 * @copyright   (C) 2021 Dimitris Grammatikogiannis
 * @license     GNU General Public License version 3
 */
namespace Ttc\Module\Invalidatecache\Administrator\Dispatcher;

\defined('_JEXEC') || die('<html><head><script>location.href=location.origin</script></head></html>');

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;

class Dispatcher extends AbstractModuleDispatcher
{
  protected function getLayoutData()
  {
    return parent::getLayoutData();
  }
}
